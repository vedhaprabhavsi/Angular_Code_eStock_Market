export class StockAggregate {
    companyCode: string;
    minPrice: number = 0.0;
    maxPrice: number = 0.0;
    avgPrice: number = 0.0;
  }