import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Company } from '../models/company';

@Injectable({
  providedIn: 'root'
})
export class CompanyService {
    
  company = new Company();

  constructor(private http: HttpClient) { }

  createCompany(company: Company): Observable<any> {
    console.log("Calling Java createCompany method");
    //return this.http.post("http://localhost:8482/command/market/company/register",company);
    return this.http.post("http://3.95.202.70:8482/command/market/company/register",company);
  }

  getCompany(companyCode: string): Observable<any> {
    console.log("Calling Java getCompany method");
    //return this.http.get<any>("http://localhost:8481/query/market/company/info/"+companyCode);
    return this.http.get<any>("http://52.90.189.7:8481/query/market/company/info/"+companyCode);
  }
}